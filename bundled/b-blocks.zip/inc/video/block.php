<?php
class BBlocksVideo extends BBlocks{
	public function __construct(){
		add_action( 'init', [$this, 'onInit'] );
	}

	function onInit(){
		register_block_type( __DIR__, [
			'render_callback' => [$this, 'render']
		] ); // Register Block
	}

	function render( $attributes ){
		extract( $attributes );

		// Enqueue assets where has block
		wp_enqueue_script( 'plyr' );
		wp_enqueue_style( 'plyr' );

		ob_start(); ?>
		<div class='wp-block-b-blocks-video <?php echo 'align' . esc_attr( $align ); ?>' id='bBlocksVideo-<?php echo esc_attr( $clientId ) ?>' data-attributes='<?php echo esc_attr( wp_json_encode( $attributes ) ); ?>'></div>

		<?php return ob_get_clean();
	}
}
new BBlocksVideo();